const String BASE_URL = 'https://presensi.dewakoding.com';

const String PREF_AUTH = 'pref-auth';
const String PREF_ID = 'pred_id';
const String PREF_NAME = 'pref_name';
const String PREF_EMAIL = 'pref_email';
const String PREF_START_SHIFT = 'pref-start-shift';
const String PREF_END_SHIFT = 'pref-end-shift';
const String PREF_NOTIF_SETTING = 'pref-notif-setting';
