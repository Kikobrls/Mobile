abstract class AppUseCase<T, P> {
  T call({P param});
}
